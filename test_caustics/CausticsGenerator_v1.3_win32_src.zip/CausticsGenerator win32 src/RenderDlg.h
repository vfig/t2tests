#if !defined(AFX_RENDERDLG_H__87321247_E199_4951_B5D2_5F028E3D9B18__INCLUDED_)
#define AFX_RENDERDLG_H__87321247_E199_4951_B5D2_5F028E3D9B18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RenderDlg.h : header file
//

#include "CRGBSurface.h"

/////////////////////////////////////////////////////////////////////////////
// CRenderDlg dialog

class CRenderDlg : public CDialog
{
// Construction
public:
	CRenderDlg(CWnd* pParent = NULL);   // standard constructor

	void Resize(int width, int height);
	void SaveOutput(const char *filename);
	CDC *GetRenderDC() { return m_renderSurface.GetDC(); }

// Dialog Data
	//{{AFX_DATA(CRenderDlg)
	enum { IDD = IDD_RENDER_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRenderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CRGBSurface m_renderSurface;

	// Generated message map functions
	//{{AFX_MSG(CRenderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RENDERDLG_H__87321247_E199_4951_B5D2_5F028E3D9B18__INCLUDED_)
