//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CausticsGenerator.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CAUSTICSGENERATOR_DIALOG    102
#define CG_IDD_PROGRESS                 103
#define CG_IDS_PROGRESS_CAPTION         104
#define IDS_ABOUT                       105
#define IDS_LOGO                        106
#define IDR_MAINFRAME                   128
#define IDD_RENDER_DLG                  130
#define IDB_ABOUTBACK                   132
#define IDC_RENDER                      1000
#define IDC_OPENGLWIN                   1001
#define IDC_DEPTH_SLIDER                1002
#define CG_IDC_PROGDLG_PROGRESS         1003
#define IDC_DEPTH_VALUE                 1004
#define CG_IDC_PROGDLG_PERCENT          1004
#define IDC_SUBDIVISIONS                1005
#define CG_IDC_PROGDLG_STATUS           1005
#define IDC_INTENSITY_SLIDER            1006
#define IDC_AMPFILTER_SLIDER            1007
#define IDC_INTENSITY_VALUE             1008
#define IDC_FREQFILTER_SLIDER           1009
#define IDC_TIMEFILTER_SLIDER           1011
#define IDC_AMPFILTER_VALUE             1015
#define IDC_FREQFILTER_VALUE            1016
#define IDC_AA_COMBO                    1017
#define IDC_PREVIEW_CHECK               1018
#define IDC_ANIMATION_FRAMES            1019
#define IDC_CURRENT_FRAME               1020
#define IDC_STEP_FRAME                  1021
#define IDC_WIDTH                       1022
#define IDC_TIMEFILTER_VALUE            1023
#define IDC_HEIGHT                      1024
#define IDC_RENDER_ANIMATION            1028
#define IDC_OUTPUT_FILENAME             1029
#define IDC_SAVE_OUTPUT_CHECK           1030
#define IDC_ABOUT                       1033
#define IDC_GRAYSCALE_CHECK             1034
#define IDC_LOGO_FRAME                  1037
#define IDC_BGCOLOR_R                   1039
#define IDC_BGCOLOR_G                   1040
#define IDC_BGCOLOR_B                   1041
#define IDC_SAVE                        1042
#define IDC_LOAD                        1043
#define IDC_SELECT_OUTPUT_NAME          1044
#define IDC_OUTPUT_EXTENSION            1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
