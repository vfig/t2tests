// CausticsGeneratorDlg.h : header file
//

#ifndef CAUSTICSGENERATORDLG_H
#define CAUSTICSGENERATORDLG_H

#if _MSC_VER > 1000
#pragma once
#endif

#include <GL/gl.h>
#include "GridMesh.h"

#include "RenderDlg.h"
#include "CWGL.h"

#include "RenderProgressDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CCausticsGeneratorDlg dialog

class CCausticsGeneratorDlg : public CDialog
{
// Construction
public:
	CCausticsGeneratorDlg(CWnd* pParent = NULL);	// standard constructor
	~CCausticsGeneratorDlg();

// Dialog Data
	//{{AFX_DATA(CCausticsGeneratorDlg)
	enum { IDD = IDD_CAUSTICSGENERATOR_DIALOG };
	CComboBox	m_aaComboCtrl;
	CSliderCtrl	m_timeFilterSliderCtrl;
	CSliderCtrl	m_freqFilterSliderCtrl;
	CSliderCtrl	m_ampFilterSliderCtrl;
	CSliderCtrl	m_intensitySliderCtrl;
	CSliderCtrl	m_depthSliderCtrl;
	CString	m_depthValueStr;
	int		m_subdivisions;
	CString	m_intensityValueStr;
	CString	m_ampFilterValueStr;
	CString	m_freqFilterValueStr;
	CString	m_timeFilterValueStr;
	BOOL	m_bPreview;
	int		m_animationFrames;
	int		m_currentFrameNr;
	int		m_width;
	int		m_height;
	BOOL	m_bSaveOutput;
	CString	m_outputFilenameStr;
	int		m_bgColorB;
	int		m_bgColorG;
	int		m_bgColorR;
	CString	m_outputExtensionStr;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCausticsGeneratorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

public:
	void InitGL();
	void DrawCaustics();

	void ResizeOutputWindow();

protected:
	void UpdateValues();
	void UpdateSliderValues();

	void ParseOutputConfig(pug::xml_node *rootNode);

// Implementation
public:
	HICON m_hIcon;

	GridMesh m_caustics;

    int m_jitterLevel;

	CRenderDlg	m_renderDlg;
	int m_oldWidth;
	int	m_oldHeight;

	CWGL m_wgl;

	bool m_bDestroyProgress;

	CRenderProgressDlg *m_progressDlg;

	// Generated message map functions
	//{{AFX_MSG(CCausticsGeneratorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRender();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnChangeSubdivisions();
	afx_msg void OnSelchangeAaCombo();
	afx_msg void OnPreviewCheck();
	afx_msg void OnChangeAnimationFrames();
	afx_msg void OnStepFrame();
	afx_msg void OnChangeCurrentFrame();
	afx_msg void OnChangeHeight();
	afx_msg void OnChangeWidth();
	afx_msg void OnRenderAnimation();
	afx_msg void OnSaveOutputCheck();
	afx_msg void OnCloseProgress();
	afx_msg void OnAbout();
	afx_msg void OnChangeBgColorB();
	afx_msg void OnChangeBgColorG();
	afx_msg void OnChangeBgColorR();
	afx_msg void OnLoad();
	afx_msg void OnSave();
	afx_msg void OnSelectOutputName();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	CFileDialog m_saveFileDialog;
	CFileDialog m_loadFileDialog;
	CFileDialog m_outputFileDialog;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif
