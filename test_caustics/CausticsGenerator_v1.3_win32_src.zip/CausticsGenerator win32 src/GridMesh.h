// GridMesh.h: interface for the GridMesh class.
// (c)2003 Kjell Andersson
//////////////////////////////////////////////////////////////////////

#ifndef GRIDMESH_H
#define GRIDMESH_H

#include "stdio.h"

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "Vector3D.h"

#include "pugxml.h"

class NormalNode {
public:
    NormalNode();
    Vector3D    normal;
    int         cnt;
};

class GridMesh  
{
public:
	GridMesh();
	~GridMesh();

    void Draw();

	double GetDepth() { return m_depth; }
	void SetDepth(double depth) { m_depth = depth; }

	double GetIntensity() { return m_setIntensity; }
	void SetIntensity(double intensity);

	int GetResultion() { return m_meshSize; }
	void SetResolution(int subdivisions);

	double GetAmpFilter() { return m_ampFilter; }
	void SetAmpFilter(double ampFilter);

	double GetFreqFilter() { return m_freqFilter; }
	void SetFreqFilter(double freqFilter);

	double GetTimeFilter() { return m_timeFilter; }
	void SetTimeFilter(double timeFilter);

    int GetNumAnimationFrames() { return m_frames; }
    void SetNumAnimationFrames(int numFrames);

    int GetCurrentFrameNr() { return m_frame+1; }
    void SetCurrentFrameNr(int frameNr);

	void SaveToFile(FILE *outFile);
	void ParseConfig(pug::xml_node *rootNode);

private:
    void Init();
    Vector3D RefractionVector(Vector3D &v1, Vector3D &normal, double i1, double i2);
    Vector3D ProjectRay(Vector3D &v1, Vector3D &dir);
    void Filter();
    void Filter2();
    void CalculateNormals();
    double Height(int x, int y);
    NormalNode* Normal(int x, int y);
    void DrawMesh(double x_off, double y_off);
    void DrawBlend(double x_off, double y_off);

	double* Height(int frame, int x, int y);

	void Recreate();

private:
	int	m_meshSize;
	int m_frames;

	double *m_mesh;
    NormalNode *m_normals;

    int m_frame;            // The current frame
    double m_size;
    double m_setIntensity;	// The intensity set by the user
    double m_intensity;		// The intensity used for drawing (based upon size of mesh).

	double m_depth;		// The water depth at which the caustics will be projected
	double m_ampFilter;
	double m_freqFilter;
	double m_timeFilter;	// Controls the "liveness" in time

    bool    m_bNeedRecreate;    // Does the mesh need to be recreated?
};

#endif

