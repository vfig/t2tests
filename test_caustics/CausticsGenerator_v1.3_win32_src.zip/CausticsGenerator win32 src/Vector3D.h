#ifndef VECTOR3D
#define VECTOR3D

class Vector3D  
{
public:
	Vector3D();
    Vector3D(double x, double y, double z);
	~Vector3D();

    Vector3D& operator=(const Vector3D &v);
    Vector3D& operator+=(const Vector3D &v);
    Vector3D& operator-=(const Vector3D &v);
    Vector3D& operator*=(const double scalar);
    Vector3D& operator/=(const double scalar);

    Vector3D  operator+(const Vector3D P) const;
    Vector3D  operator-(const Vector3D P) const;
    Vector3D  operator-() const;
    Vector3D  operator*(double scalar) const;
    Vector3D  operator/(double scalar) const;

    double      Length();
    Vector3D&   Normalize();
    Vector3D    Normalized();

    static double   DotProduct(const Vector3D &v1, const Vector3D &v2);
    static Vector3D CrossProduct(const Vector3D &v1, const Vector3D &v2);
    static double   Distance(const Vector3D &v1, const Vector3D &v2);

private:
	

public:
    double  x;
    double  y;
    double  z;
};

#endif
