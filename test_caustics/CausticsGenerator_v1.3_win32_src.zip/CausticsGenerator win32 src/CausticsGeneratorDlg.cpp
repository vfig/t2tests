// CausticsGeneratorDlg.cpp : implementation file
// (c) 2003 Kjell Andersson, Mathias Bergvall

#include "stdafx.h"
#include "CausticsGenerator.h"
#include "CausticsGeneratorDlg.h"

#include "pugxml.h"
using namespace pug;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DEPTH_MIN 0.0
#define DEPTH_MAX 10.0
#define INTENSITY_MIN 0.0
#define INTENSITY_MAX 0.5
#define AMP_FILTER_MIN 0.0
#define AMP_FILTER_MAX 100.0
#define FREQ_FILTER_MIN 0.0
#define FREQ_FILTER_MAX 5.0
#define TIME_FILTER_MIN 5.0
#define TIME_FILTER_MAX 55.0

#define MSG_CLOSE_PROGRESS (WM_USER+0x01)

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	CBitmap m_backBitmap;

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCausticsGeneratorDlg dialog

CCausticsGeneratorDlg::CCausticsGeneratorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCausticsGeneratorDlg::IDD, pParent),
	  m_saveFileDialog(
		false, ".cst", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR,
		"Caustic Generator Files (*.cst)|*.cst|All Files (*.*)|*.*|"),
	  m_loadFileDialog(
		true, ".cst", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR,
		"Caustic Generator Files (*.cst)|*.cst|All Files (*.*)|*.*|"),
	  m_outputFileDialog(
		true, ".cst", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR,
		"Bitmap file (*.bmp)|*.bmp|All Files (*.*)|*.*|")


{
	//{{AFX_DATA_INIT(CCausticsGeneratorDlg)
	m_depthValueStr = _T("");
	m_subdivisions = m_caustics.GetResultion();
	m_intensityValueStr = _T("");
	m_ampFilterValueStr = _T("");
	m_freqFilterValueStr = _T("");
	m_timeFilterValueStr = _T("");
	m_bPreview = FALSE;
	m_animationFrames = 0;
	m_currentFrameNr = 1;
	m_width = 256;
	m_height = 256;
	m_bSaveOutput = FALSE;
	m_outputFilenameStr = _T("");
	m_bgColorB = 204;
	m_bgColorG = 76;
	m_bgColorR = 51;
	m_outputExtensionStr = _T("_###.bmp");
	//}}AFX_DATA_INIT

	m_oldWidth = 0;
	m_oldHeight = 0;
    m_jitterLevel = 1;

	m_depthValueStr.Format("%.2f m", m_caustics.GetDepth());
	m_intensityValueStr.Format("%.4f", m_caustics.GetIntensity());
	m_ampFilterValueStr.Format("%.1f", m_caustics.GetAmpFilter());
	m_freqFilterValueStr.Format("%.1f", m_caustics.GetFreqFilter());
	m_timeFilterValueStr.Format("%.1f", m_caustics.GetTimeFilter());

    m_animationFrames = m_caustics.GetNumAnimationFrames();
    m_currentFrameNr = m_caustics.GetCurrentFrameNr();

	m_progressDlg = NULL;

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CCausticsGeneratorDlg::~CCausticsGeneratorDlg()
{
	if (m_progressDlg) {
		delete m_progressDlg;
		m_progressDlg = NULL;
	}
}


void CCausticsGeneratorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCausticsGeneratorDlg)
	DDX_Control(pDX, IDC_AA_COMBO, m_aaComboCtrl);
	DDX_Control(pDX, IDC_TIMEFILTER_SLIDER, m_timeFilterSliderCtrl);
	DDX_Control(pDX, IDC_FREQFILTER_SLIDER, m_freqFilterSliderCtrl);
	DDX_Control(pDX, IDC_AMPFILTER_SLIDER, m_ampFilterSliderCtrl);
	DDX_Control(pDX, IDC_INTENSITY_SLIDER, m_intensitySliderCtrl);
	DDX_Control(pDX, IDC_DEPTH_SLIDER, m_depthSliderCtrl);
	DDX_Text(pDX, IDC_DEPTH_VALUE, m_depthValueStr);
	DDX_Text(pDX, IDC_SUBDIVISIONS, m_subdivisions);
	DDV_MinMaxInt(pDX, m_subdivisions, 1, 2048);
	DDX_Text(pDX, IDC_INTENSITY_VALUE, m_intensityValueStr);
	DDX_Text(pDX, IDC_AMPFILTER_VALUE, m_ampFilterValueStr);
	DDX_Text(pDX, IDC_FREQFILTER_VALUE, m_freqFilterValueStr);
	DDX_Text(pDX, IDC_TIMEFILTER_VALUE, m_timeFilterValueStr);
	DDX_Check(pDX, IDC_PREVIEW_CHECK, m_bPreview);
	DDX_Text(pDX, IDC_ANIMATION_FRAMES, m_animationFrames);
	DDV_MinMaxInt(pDX, m_animationFrames, 1, 1000);
	DDX_Text(pDX, IDC_CURRENT_FRAME, m_currentFrameNr);
	DDV_MinMaxInt(pDX, m_currentFrameNr, 1, 1000);
	DDX_Text(pDX, IDC_WIDTH, m_width);
	DDV_MinMaxInt(pDX, m_width, 1, 1024);
	DDX_Text(pDX, IDC_HEIGHT, m_height);
	DDV_MinMaxInt(pDX, m_height, 1, 1024);
	DDX_Check(pDX, IDC_SAVE_OUTPUT_CHECK, m_bSaveOutput);
	DDX_Text(pDX, IDC_OUTPUT_FILENAME, m_outputFilenameStr);
	DDX_Text(pDX, IDC_BGCOLOR_B, m_bgColorB);
	DDX_Text(pDX, IDC_BGCOLOR_G, m_bgColorG);
	DDX_Text(pDX, IDC_BGCOLOR_R, m_bgColorR);
	DDX_Text(pDX, IDC_OUTPUT_EXTENSION, m_outputExtensionStr);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCausticsGeneratorDlg, CDialog)
	//{{AFX_MSG_MAP(CCausticsGeneratorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RENDER, OnRender)
	ON_WM_HSCROLL()
	ON_EN_CHANGE(IDC_SUBDIVISIONS, OnChangeSubdivisions)
	ON_CBN_SELCHANGE(IDC_AA_COMBO, OnSelchangeAaCombo)
	ON_BN_CLICKED(IDC_PREVIEW_CHECK, OnPreviewCheck)
	ON_EN_CHANGE(IDC_ANIMATION_FRAMES, OnChangeAnimationFrames)
	ON_BN_CLICKED(IDC_STEP_FRAME, OnStepFrame)
	ON_EN_CHANGE(IDC_CURRENT_FRAME, OnChangeCurrentFrame)
	ON_EN_CHANGE(IDC_HEIGHT, OnChangeHeight)
	ON_EN_CHANGE(IDC_WIDTH, OnChangeWidth)
	ON_BN_CLICKED(IDC_RENDER_ANIMATION, OnRenderAnimation)
	ON_BN_CLICKED(IDC_SAVE_OUTPUT_CHECK, OnSaveOutputCheck)
	ON_MESSAGE(MSG_CLOSE_PROGRESS,OnCloseProgress)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_EN_CHANGE(IDC_BGCOLOR_B, OnChangeBgColorB)
	ON_EN_CHANGE(IDC_BGCOLOR_G, OnChangeBgColorG)
	ON_EN_CHANGE(IDC_BGCOLOR_R, OnChangeBgColorR)
	ON_BN_CLICKED(IDC_LOAD, OnLoad)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_SELECT_OUTPUT_NAME, OnSelectOutputName)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCausticsGeneratorDlg message handlers

BOOL CCausticsGeneratorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_depthSliderCtrl.SetRangeMin(0);
	m_depthSliderCtrl.SetRangeMax(100);
	m_depthSliderCtrl.SetTicFreq(10);

	m_intensitySliderCtrl.SetRangeMin(0);
	m_intensitySliderCtrl.SetRangeMax(100);
	m_intensitySliderCtrl.SetTicFreq(10);

	m_ampFilterSliderCtrl.SetRangeMin(0);
	m_ampFilterSliderCtrl.SetRangeMax(100);
	m_ampFilterSliderCtrl.SetTicFreq(10);

	m_freqFilterSliderCtrl.SetRangeMin(0);
	m_freqFilterSliderCtrl.SetRangeMax(100);
	m_freqFilterSliderCtrl.SetTicFreq(10);

	m_timeFilterSliderCtrl.SetRangeMin(0);
	m_timeFilterSliderCtrl.SetRangeMax(100);
	m_timeFilterSliderCtrl.SetTicFreq(10);

    m_aaComboCtrl.SetCurSel(0);

	UpdateValues();
	UpdateData(false);

	m_renderDlg.Create(IDD_RENDER_DLG, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCausticsGeneratorDlg::UpdateValues()
{
	m_depthSliderCtrl.SetPos((int)(100*(m_caustics.GetDepth()-DEPTH_MIN)/(DEPTH_MAX-DEPTH_MIN)));
	m_intensitySliderCtrl.SetPos((int)(100*(m_caustics.GetIntensity()-INTENSITY_MIN)/(INTENSITY_MAX-INTENSITY_MIN)));
	m_ampFilterSliderCtrl.SetPos((int)(100*(m_caustics.GetAmpFilter()-AMP_FILTER_MIN)/(AMP_FILTER_MAX-AMP_FILTER_MIN)));
	m_freqFilterSliderCtrl.SetPos((int)(100*(m_caustics.GetFreqFilter()-FREQ_FILTER_MIN)/(FREQ_FILTER_MAX-FREQ_FILTER_MIN)));
	m_timeFilterSliderCtrl.SetPos((int)(100*(m_caustics.GetTimeFilter()-TIME_FILTER_MIN)/(TIME_FILTER_MAX-TIME_FILTER_MIN)));

    m_animationFrames = m_caustics.GetNumAnimationFrames();
    m_currentFrameNr = m_caustics.GetCurrentFrameNr();
	m_outputExtensionStr.Format("_%.3d.bmp", m_currentFrameNr);
	m_subdivisions = m_caustics.GetResultion();

	switch(m_jitterLevel) {
	case 1:
	    m_aaComboCtrl.SetCurSel(0);
		break;
	case 2:
	    m_aaComboCtrl.SetCurSel(1);
		break;
	case 4:
	    m_aaComboCtrl.SetCurSel(2);
		break;
	case 8:
	    m_aaComboCtrl.SetCurSel(3);
		break;
	case 16:
	    m_aaComboCtrl.SetCurSel(4);
		break;
	default:
	    m_aaComboCtrl.SetCurSel(5);
		break;
	}
}

void CCausticsGeneratorDlg::ResizeOutputWindow()
{
	m_renderDlg.Resize(m_width, m_height);
}


bool RenderCausticsProc(CCausticsGeneratorDlg *causticsGeneratorDlg)
{
	bool retVal = true;

	causticsGeneratorDlg->m_wgl.Begin(causticsGeneratorDlg->m_renderDlg.GetRenderDC());

	causticsGeneratorDlg->m_renderDlg.ShowWindow(SW_NORMAL);
	if (causticsGeneratorDlg->m_width != causticsGeneratorDlg->m_oldWidth || causticsGeneratorDlg->m_height != causticsGeneratorDlg->m_oldHeight) {
		causticsGeneratorDlg->ResizeOutputWindow();
		causticsGeneratorDlg->m_oldWidth = causticsGeneratorDlg->m_width;
		causticsGeneratorDlg->m_oldHeight = causticsGeneratorDlg->m_height;
	}

	causticsGeneratorDlg->InitGL();

	static float zpos = 0;
	static float xang = 0;
	static float yang = 0;

    struct jitter_coord {
        float x;
        float y;
    };
    struct jitter_coord j1[] = { {0,0} };
    struct jitter_coord j2[] = { {0.25, 0.75}, {0.75, 0.25} };
    struct jitter_coord j4[] = { {0.375, 0.25}, {0.125, 0.75}, {0.875, 0.25}, {0.625, 0.75} };
    struct jitter_coord j8[] = {
        {0.5625, 0.4375}, {0.0625, 0.9375}, {0.3125, 0.6875}, {0.6875, 0.8125},
        {0.8125, 0.1875}, {0.9375, 0.5625}, {0.4375, 0.0625}, {0.1875, 0.3125} };
    struct jitter_coord j16[] = {
        {0.375, 0.4375}, {0.625, 0.0625}, {0.875, 0.1875}, {0.125, 0.0625}, 
        {0.375, 0.6875}, {0.875, 0.4375}, {0.625, 0.5625}, {0.375, 0.9375}, 
        {0.625, 0.3125}, {0.125, 0.5625}, {0.125, 0.8125}, {0.375, 0.1875}, 
        {0.875, 0.9375}, {0.875, 0.6875}, {0.125, 0.3125}, {0.625, 0.8125} };

    struct jitter_coord *pJ;

    if (causticsGeneratorDlg->m_jitterLevel == 16) {
        pJ = j16;
    } else if (causticsGeneratorDlg->m_jitterLevel == 8) {
        pJ = j8;
    } else if (causticsGeneratorDlg->m_jitterLevel == 4) {
        pJ = j4;
    } else if (causticsGeneratorDlg->m_jitterLevel == 2) {
        pJ = j2;
    } else {
        causticsGeneratorDlg->m_jitterLevel = 1;
        pJ = j1;
    }

    if (causticsGeneratorDlg->m_jitterLevel != 1) {
        glClearAccum(0.0, 0.0, 0.0, 0.0);
        glClear(GL_ACCUM_BUFFER_BIT);
    }

    GLint viewport[4];
    glGetIntegerv (GL_VIEWPORT, viewport);

    for (int jitter=0; jitter < causticsGeneratorDlg->m_jitterLevel; jitter++) {
		if (causticsGeneratorDlg->m_progressDlg != NULL && causticsGeneratorDlg->m_progressDlg->CheckCancelButton()) {
			// cancel rendering
			retVal = false;
			break;
		}

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glLoadIdentity();
        glTranslatef (pJ[jitter].x*20.0f/viewport[2], pJ[jitter].y*20.0f/viewport[3], 0.0f);
        causticsGeneratorDlg->m_caustics.Draw();

        if (causticsGeneratorDlg->m_jitterLevel != 1) {
            glAccum(GL_ACCUM, 1.0f/causticsGeneratorDlg->m_jitterLevel);
        }
    }
    
    if (causticsGeneratorDlg->m_jitterLevel != 1) {
        glAccum(GL_RETURN, 1.0);
    }
    glFlush();

	if (causticsGeneratorDlg->m_bSaveOutput) {
		char filename[100];
		sprintf(filename, "%s_%.3d.bmp", causticsGeneratorDlg->m_outputFilenameStr, causticsGeneratorDlg->m_caustics.GetCurrentFrameNr());
		causticsGeneratorDlg->m_renderDlg.SaveOutput(filename);
	}
//    SwapBuffers(m_hDC);

	causticsGeneratorDlg->m_wgl.End();
	causticsGeneratorDlg->m_renderDlg.Invalidate();

	return retVal;
}


void CCausticsGeneratorDlg::DrawCaustics()
{
	UpdateData(true);

    BeginWaitCursor();
	RenderCausticsProc(this);

    EndWaitCursor();
}

void CCausticsGeneratorDlg::InitGL()
{
	glViewport(0,0,m_width,m_height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    glOrtho(-10,10,-10,10,0.0,100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
  	glShadeModel(GL_SMOOTH);
    glClearColor(m_bgColorR/255.0f, m_bgColorG/255.0f, m_bgColorB/255.0f, 0.0f); // Blue background
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
    //glEnable(GL_COLOR_MATERIAL);
    glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glEnable(GL_LIGHT1);
    glEnable(GL_LIGHTING);
}


void CCausticsGeneratorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCausticsGeneratorDlg::OnPaint() 
{
	if (m_bDestroyProgress) {
		if (m_progressDlg) {
			delete m_progressDlg;
			m_progressDlg = NULL;
		}
	}

	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this); // device context for painting





		CBitmap gridBitmap;
		gridBitmap.LoadBitmap(IDB_ABOUTBACK);
		BITMAP bm;

		CWnd *wnd = GetDlgItem(IDC_LOGO_FRAME);
		if (wnd != NULL) {
			RECT rect;
			wnd->GetWindowRect(&rect);
			ScreenToClient(&rect);

			CDC dcMem;
			dcMem.CreateCompatibleDC(NULL);
			CBitmap *bmOld = dcMem.SelectObject(&gridBitmap);
			
			GetObject(gridBitmap, sizeof(bm), &bm);
			
			int width = rect.right - rect.left-2;
			int height = rect.bottom - rect.top-2;

			dc.BitBlt(rect.left+1, rect.top+1, width, height, &dcMem, 40, 90, SRCCOPY);
			
			dcMem.SelectObject(bmOld);
			dcMem.DeleteDC();

			CString logoStr;
			logoStr.LoadString(IDS_LOGO);

			dc.SetBkMode(TRANSPARENT);
			RECT textRect = {rect.left, rect.top + 35, width, height};
			dc.SetTextColor(COLORREF(0x000000));
			dc.DrawText(logoStr, &textRect, DT_CENTER);
			textRect.left -= 1;
			textRect.top -= 1;
			dc.SetTextColor(COLORREF(0xffffff));
			dc.DrawText(logoStr, &textRect, DT_CENTER);
		
		}

		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCausticsGeneratorDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCausticsGeneratorDlg::OnRender() 
{
	DrawCaustics();
}

void CCausticsGeneratorDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	UpdateSliderValues();

	// Update image
    if (m_bPreview) {
    	DrawCaustics();
    }

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CCausticsGeneratorDlg::UpdateSliderValues()
{
	int currPos;

	// Depth
	currPos = m_depthSliderCtrl.GetPos();

	double currDepth = (DEPTH_MAX-DEPTH_MIN) * (currPos/100.0) + DEPTH_MIN;

	m_depthValueStr.Format("%.2f m", currDepth);

	m_caustics.SetDepth(currDepth);


	// Intensity
	currPos = m_intensitySliderCtrl.GetPos();

	double currIntensity = (INTENSITY_MAX-INTENSITY_MIN) * (currPos/100.0) + INTENSITY_MIN;

	m_intensityValueStr.Format("%.4f", currIntensity);

	m_caustics.SetIntensity(currIntensity);


	// AmpFilter
	currPos = m_ampFilterSliderCtrl.GetPos();

	double currAmpFilter = (AMP_FILTER_MAX-AMP_FILTER_MIN) * (currPos/100.0) + AMP_FILTER_MIN;

	m_ampFilterValueStr.Format("%.1f", currAmpFilter);

	m_caustics.SetAmpFilter(currAmpFilter);


	// FreqFilter
	currPos = m_freqFilterSliderCtrl.GetPos();

	double currFreqFilter = (FREQ_FILTER_MAX-FREQ_FILTER_MIN) * (currPos/100.0) + FREQ_FILTER_MIN;

	m_freqFilterValueStr.Format("%.1f", currFreqFilter);

	m_caustics.SetFreqFilter(currFreqFilter);


	// TimeFilter
	currPos = m_timeFilterSliderCtrl.GetPos();

	double currTimeFilter = (TIME_FILTER_MAX-TIME_FILTER_MIN) * (currPos/100.0) + TIME_FILTER_MIN;

	m_timeFilterValueStr.Format("%.1f", currTimeFilter);

	m_caustics.SetTimeFilter(currTimeFilter);

	UpdateData(false);
}

void CCausticsGeneratorDlg::OnChangeSubdivisions() 
{
	UpdateData(true);
	m_caustics.SetResolution(m_subdivisions);
    if (m_bPreview) {
    	DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnSelchangeAaCombo() 
{
    int curSel = m_aaComboCtrl.GetCurSel();	
    switch(curSel) {
    case 0:
        m_jitterLevel = 1;
        break;
    case 1:
        m_jitterLevel = 2;
        break;
    case 2:
        m_jitterLevel = 4;
        break;
    case 3:
        m_jitterLevel = 8;
        break;
    case 4:
        m_jitterLevel = 16;
        break;
    default:
        m_jitterLevel = 1;
        break;
    }
    if (m_bPreview) {
        DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnPreviewCheck() 
{
    UpdateData(true);
    if (m_bPreview) {
        DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnChangeAnimationFrames() 
{
	UpdateData(true);
	if (m_caustics.GetCurrentFrameNr() > m_animationFrames) {
		m_caustics.SetCurrentFrameNr(1);
        m_currentFrameNr = 1;
        UpdateData(false);
	}
	if (m_animationFrames < 1) {
		m_animationFrames = 1;
		UpdateData(false);
	}
	m_caustics.SetNumAnimationFrames(m_animationFrames);
    if (m_bPreview) {
    	DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnStepFrame() 
{
    m_currentFrameNr++;
    if (m_currentFrameNr > m_caustics.GetNumAnimationFrames()) {
        m_currentFrameNr = 1;
    }
    m_caustics.SetCurrentFrameNr(m_currentFrameNr);
	m_outputExtensionStr.Format("_%.3d.bmp", m_currentFrameNr);
    UpdateData(false);
    if (m_bPreview) {
    	DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnChangeCurrentFrame() 
{
	UpdateData(true);
    if (m_currentFrameNr > m_caustics.GetNumAnimationFrames()) {
        m_currentFrameNr = m_caustics.GetNumAnimationFrames();
    } else
	if (m_currentFrameNr < 1) {
		m_currentFrameNr = 1;
	}
	m_outputExtensionStr.Format("_%.3d.bmp", m_currentFrameNr);
	UpdateData(false);

	m_caustics.SetCurrentFrameNr(m_currentFrameNr);
    if (m_bPreview) {
    	DrawCaustics();
    }
}

void CCausticsGeneratorDlg::OnChangeHeight() 
{
	UpdateData(true);
	if (m_bPreview) {
		DrawCaustics();
	}
}

void CCausticsGeneratorDlg::OnChangeWidth() 
{
	UpdateData(true);
	if (m_bPreview) {
		DrawCaustics();
	}
}

UINT RenderAnimThreadProc( LPVOID pParam )
{
	CCausticsGeneratorDlg *causticsGeneratorDlg = (CCausticsGeneratorDlg *)pParam;

	int numAnimFrames = causticsGeneratorDlg->m_caustics.GetNumAnimationFrames();

	for (int i=1; i <= numAnimFrames; i++) {
		CString statusStr;
		statusStr.Format("Rendering frame %d of %d...", i, numAnimFrames);
		causticsGeneratorDlg->m_progressDlg->SetStatus(statusStr);
		causticsGeneratorDlg->m_caustics.SetCurrentFrameNr(i);
		if (!RenderCausticsProc(causticsGeneratorDlg)) {
			break;
		}
		causticsGeneratorDlg->m_progressDlg->SetPos(i*100/numAnimFrames);
		if (causticsGeneratorDlg->m_progressDlg->CheckCancelButton()) {
			break;
		}
	}

	// UGLY as hell but works... WM_USER msg crashes...
	causticsGeneratorDlg->m_bDestroyProgress = true;
	::PostMessage(causticsGeneratorDlg->m_hWnd, WM_PAINT, 0, 0);
	return 0;
}

void CCausticsGeneratorDlg::OnRenderAnimation() 
{
	UpdateData(true);
	BOOL saveStatus = m_bSaveOutput;
	m_bSaveOutput = true;

	if (m_progressDlg != NULL) {
		delete m_progressDlg;
	}
	m_progressDlg = new CRenderProgressDlg;
	m_progressDlg->Create(this);
	m_progressDlg->SetPos(0);
	m_bDestroyProgress = false;

	AfxBeginThread(RenderAnimThreadProc, this);

	m_bSaveOutput = saveStatus;
	UpdateData(false);
}

void CCausticsGeneratorDlg::OnSaveOutputCheck() 
{
	UpdateData(true);
}

void CCausticsGeneratorDlg::OnCloseProgress()
{
	if (m_progressDlg) {
		delete m_progressDlg;
		m_progressDlg = NULL;
	}
}

void CAboutDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	BITMAP bm;

	CDC dcMem;
	dcMem.CreateCompatibleDC(NULL);
	CBitmap *bmOld = dcMem.SelectObject(&m_backBitmap);
	
	GetObject(m_backBitmap, sizeof(bm), &bm);

	dc.BitBlt(0, 0, bm.bmWidth, bm.bmHeight, &dcMem, 0, 0, SRCCOPY);

	dcMem.SelectObject(bmOld);
	dcMem.DeleteDC();

	dc.SelectObject(GetStockObject(DEFAULT_GUI_FONT));

	CString aboutString;
	aboutString.LoadString(IDS_ABOUT);

	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(COLORREF(0x000000));
	RECT textRect = {10, 10, bm.bmWidth-10, bm.bmHeight-10};
	dc.DrawText(aboutString, &textRect, DT_LEFT);
	textRect.left += 2;
	textRect.top += 2;
	dc.SetTextColor(COLORREF(0x000000));
	dc.DrawText(aboutString, &textRect, DT_LEFT);
	textRect.left -= 1;
	textRect.top -= 1;
	dc.SetTextColor(COLORREF(0xffffff));
	dc.DrawText(aboutString, &textRect, DT_LEFT);
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_backBitmap.LoadBitmap(MAKEINTRESOURCE(IDB_ABOUTBACK));
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCausticsGeneratorDlg::OnAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CCausticsGeneratorDlg::OnChangeBgColorB() 
{
	UpdateData(true);
	if (m_bgColorB > 255) {
		m_bgColorB = 255;
		UpdateData(false);
	}
	if (m_bgColorB < 0) {
		m_bgColorB = 0;
		UpdateData(false);
	}
	if (m_bPreview) {
		DrawCaustics();
	}
}

void CCausticsGeneratorDlg::OnChangeBgColorG() 
{
	UpdateData(true);
	if (m_bgColorG > 255) {
		m_bgColorG = 255;
		UpdateData(false);
	}
	if (m_bgColorG < 0) {
		m_bgColorG = 0;
		UpdateData(false);
	}
	if (m_bPreview) {
		DrawCaustics();
	}
}

void CCausticsGeneratorDlg::OnChangeBgColorR() 
{
	UpdateData(true);
	if (m_bgColorR > 255) {
		m_bgColorR = 255;
		UpdateData(false);
	}
	if (m_bgColorR < 0) {
		m_bgColorR = 0;
		UpdateData(false);
	}
	if (m_bPreview) {
		DrawCaustics();
	}
}

void CCausticsGeneratorDlg::OnLoad() 
{
	xml_parser *xml = new xml_parser();
	try {
		if (m_loadFileDialog.DoModal() == IDOK) {
			if (!xml->parse_file(m_loadFileDialog.GetPathName())) {
				throw "No valid Caustics Generator file.";
			}

			xml_node document = xml->document();
			xml_node root = document.first_node(pug::node_element);
			if (!strcmp(root.name(), "CAUSTICS_GENERATOR") == 0) {
				throw "No valid Caustics Generator file!";
			}

			// We now have a valid load file.
			// Parse XML tags.
			for (int i=0; i < root.children(); i++) {
				xml_node itemNode = root.child(i);
				if (strcmp(itemNode.name(), "CAUSTICS") == 0) {
					m_caustics.ParseConfig(&itemNode);
				}
				if (strcmp(itemNode.name(), "OUTPUT") == 0) {
					ParseOutputConfig(&itemNode);
				}
			}
		}
	} catch(const char *errorStr) {
		AfxMessageBox(errorStr);
	}
	delete xml;

	UpdateValues();
	UpdateSliderValues();
	UpdateData(true);

    if (m_bPreview) {
    	DrawCaustics();
    } else {
		if (m_renderDlg.IsWindowVisible()) {
			m_renderDlg.ShowWindow(SW_HIDE);
		}
	}
}

void CCausticsGeneratorDlg::ParseOutputConfig(pug::xml_node *rootNode)
{
	for (int i=0; i < rootNode->children(); i++) {
		pug::xml_node itemNode = rootNode->child(i);

		float fValue = 0;
		int iValue = 0;

		if (stricmp("SIZE", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("width").value(), "%d", &iValue);
			m_width = iValue;
			sscanf(itemNode.attribute("height").value(), "%d", &iValue);
			m_height = iValue;
		}
		if (stricmp("SUPERSAMPLING", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%d", &iValue);
			m_jitterLevel = iValue;
		}
		if (stricmp("BGCOLOR", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("r").value(), "%d", &iValue);
			m_bgColorR = iValue;
			sscanf(itemNode.attribute("g").value(), "%d", &iValue);
			m_bgColorG = iValue;
			sscanf(itemNode.attribute("b").value(), "%d", &iValue);
			m_bgColorB = iValue;
		}
		if (stricmp("PREVIEW", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%d", &iValue);
			if (iValue) {
				m_bPreview = true;
			} else {
				m_bPreview = false;
			}
		}
		if (stricmp("FILENAME", itemNode.name()) == 0) {
			m_outputFilenameStr = itemNode.attribute("text").value();
		}
	}
}


void CCausticsGeneratorDlg::OnSave() 
{
	UpdateData(true);

	if (m_saveFileDialog.DoModal() == IDOK) {
		FILE *saveFile = fopen(m_saveFileDialog.GetPathName(), "w");
		if (saveFile) {
			// Save caustics parameters
			fprintf(saveFile, "<CAUSTICS_GENERATOR>\n");
			m_caustics.SaveToFile(saveFile);

			// Save OUTPUT data
			fprintf(saveFile, "<OUTPUT>\n");
			fprintf(saveFile, "\t<SIZE width=\"%i\" height=\"%i\"/>\n", m_width, m_height);
			fprintf(saveFile, "\t<SUPERSAMPLING value=\"%i\"/>\n", m_jitterLevel);
			fprintf(saveFile, "\t<BGCOLOR r=\"%i\" g=\"%i\" b=\"%i\"/>\n", m_bgColorR, m_bgColorG, m_bgColorB);
			fprintf(saveFile, "\t<PREVIEW value=\"%i\"/>\n", m_bPreview);
			fprintf(saveFile, "\t<FILENAME text=\"%s\"/>\n", m_outputFilenameStr);
			fprintf(saveFile, "</OUTPUT>\n");

			fprintf(saveFile, "</CAUSTICS_GENERATOR>\n");

			fclose(saveFile);
		} else {
			// File could not be opened
			AfxMessageBox("ERROR: Could not open file " + m_saveFileDialog.GetPathName() + " for writing.");
		}
	}
}

void CCausticsGeneratorDlg::OnSelectOutputName() 
{
	if (m_outputFileDialog.DoModal() == IDOK) {
		m_outputFilenameStr = m_outputFileDialog.GetPathName();

		// Remove _###.bmp if any
		CString numberExtension(m_outputFilenameStr.Right(8));
		numberExtension.SetAt(1, '#');
		numberExtension.SetAt(2, '#');
		numberExtension.SetAt(3, '#');
		if (numberExtension.CompareNoCase("_###.bmp") == 0) {
			m_outputFilenameStr = m_outputFilenameStr.Left(m_outputFilenameStr.GetLength() - 8);
		} else
		// Remove .bmp extension if any
		if (m_outputFilenameStr.Right(4).CompareNoCase(".bmp") == 0) {
			m_outputFilenameStr = m_outputFilenameStr.Left(m_outputFilenameStr.GetLength() - 4);
		}
		UpdateData(false);
	}
}
