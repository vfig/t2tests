// Vector3D implementation
// (c) 2003 Kjell Andersson

#include "Vector3D.h"
#include <math.h>

Vector3D::Vector3D()
{
    this->x = 0;
    this->y = 0;
    this->z = 0;
}

Vector3D::Vector3D(double x, double y, double z)
{
    this->x = x;
    this->y = y;
    this->z = z;
}

Vector3D::~Vector3D()
{

}

Vector3D& Vector3D::operator=(const Vector3D &v)
{
    this->x = v.x;
    this->y = v.y;
    this->z = v.z;
    return *this;
}

Vector3D& Vector3D::operator+=(const Vector3D &v)
{
    this->x += v.x;
    this->y += v.y;
    this->z += v.z;
    return *this;
}

Vector3D& Vector3D::operator-=(const Vector3D &v)
{
    this->x -= v.x;
    this->y -= v.y;
    this->z -= v.z;
    return *this;
}

Vector3D& Vector3D::operator*=(const double scalar)
{
    this->x *= scalar;
    this->y *= scalar;
    this->z *= scalar;
    return *this;
}

Vector3D& Vector3D::operator/=(const double scalar)
{
    this->x /= scalar;
    this->y /= scalar;
    this->z /= scalar;
    return *this;
}

Vector3D Vector3D::operator+(const Vector3D v) const
{
    return Vector3D(x+v.x, y+v.y, z+v.z);
}

Vector3D Vector3D::operator-(const Vector3D v) const
{
    return Vector3D(x-v.x, y-v.y, z-v.z);
}

Vector3D Vector3D::operator-() const
{
    return Vector3D(-x, -y, -z);
}

Vector3D Vector3D::operator*(double scalar) const
{
    return Vector3D(x*scalar, y*scalar, z*scalar);
}

Vector3D Vector3D::operator/(double scalar) const
{
    return Vector3D(x/scalar, y/scalar, z/scalar);
}

double Vector3D::Length()
{
    return sqrt(x*x + y*y + z*z);
}

Vector3D& Vector3D::Normalize()
{
    double length = Length();
    this->x /= length;
    this->y /= length;
    this->z /= length;
    return *this;
}

Vector3D Vector3D::Normalized()
{
    double length = Length();
    return Vector3D(x/length, y/length, z/length);
}

double Vector3D::DotProduct(const Vector3D &v1, const Vector3D &v2)
{
   return ((v1.x)*(v2.x) + (v1.y)*(v2.y) + (v1.z)*(v2.z));
}

Vector3D Vector3D::CrossProduct(const Vector3D &v1, const Vector3D &v2)
{
    return Vector3D(v1.y*v2.z - v1.z*v2.y,
                    v1.z*v2.x - v1.x*v2.z,
                    v1.x*v2.y - v1.y*v2.x);
}

double Vector3D::Distance(const Vector3D &v1, const Vector3D &v2)
{
    return (v2-v1).Length();
}

