// RenderDlg.cpp : implementation file
// (c) 2003 Kjell Andersson, Mathias Bergvall

#include "stdafx.h"
#include "CausticsGenerator.h"
#include "RenderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRenderDlg dialog


CRenderDlg::CRenderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRenderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRenderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CRenderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRenderDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRenderDlg, CDialog)
	//{{AFX_MSG_MAP(CRenderDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRenderDlg message handlers

BOOL CRenderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	Resize(256, 256);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRenderDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	m_renderSurface.Blt(GetDC(), 0, 0, 0, 0);
}

void CRenderDlg::Resize(int width, int height)
{
	RECT wndRect;
	RECT clientRect;
	GetWindowRect(&wndRect);
	GetClientRect(&clientRect);
	int borderWidth = (wndRect.right - wndRect.left) - (clientRect.right - clientRect.left);
	int borderHeight = (wndRect.bottom - wndRect.top) - (clientRect.bottom - clientRect.top);
	wndRect.right = wndRect.left + width + borderWidth;
	wndRect.bottom = wndRect.top + height + borderHeight;
	MoveWindow(&wndRect);

	m_renderSurface.Delete();
	m_renderSurface.Create(width, height);
}

void CRenderDlg::SaveOutput(const char *filename)
{
	m_renderSurface.SaveDIB(filename, true);
}
