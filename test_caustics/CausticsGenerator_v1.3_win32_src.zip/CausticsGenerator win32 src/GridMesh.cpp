// GridMesh.cpp: implementation of the GridMesh class.
// (c) 2003 Kjell Andersson, Mathias Bergvall
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <math.h>
#include "GridMesh.h"
#include "Vector3D.h"
#include "rfftw.h"

//////////////////////////////////////////////////////////////////////

#pragma comment (lib, "rfftw2dll.lib") 

NormalNode::NormalNode()
: normal(0,0,0)
{
    cnt = 0;
}

GridMesh::GridMesh()
{
	m_meshSize = 64;
	m_frames = 32;
	m_mesh = NULL;
	m_normals = NULL;
	m_depth = 1.5;
	m_setIntensity = 0.05;
	m_ampFilter = 30.0;
    m_freqFilter = 1.5;
	m_timeFilter = 32;
    m_bNeedRecreate = true;
    m_frame = 0;
}

GridMesh::~GridMesh()
{
	if (m_mesh != NULL) {
		delete [] m_mesh;
        m_mesh = NULL;
	}
	if (m_normals != NULL) {
		delete [] m_normals;
        m_normals = NULL;
	}
}

void GridMesh::Recreate()
{
	if (m_mesh != NULL) {
		delete [] m_mesh;
        m_mesh = NULL;
	}
    m_mesh = new double [m_frames*m_meshSize*m_meshSize];
	if (m_normals != NULL) {
		delete [] m_normals;
        m_normals = NULL;
	}
    m_normals = new NormalNode[m_meshSize*m_meshSize];

    m_size = m_meshSize/20.0;
    m_intensity = m_setIntensity/(m_size*m_size);
    Init();
	CalculateNormals();

    m_bNeedRecreate = false;
}

void GridMesh::Init()
{
    srand(0);
    for (int f = 0; f < m_frames; f++) {
        for (int y = 0; y < m_meshSize; y++) {
            for (int x = 0; x < m_meshSize; x++) {
                *Height(f,x,y) = 0.02*(((double)rand())/RAND_MAX-0.5);
            }
        }
    }
    Filter();
}

void GridMesh::SetResolution(int subdivisions)
{
	if (subdivisions >= 1) {
		m_meshSize = subdivisions;
        m_bNeedRecreate = true;
	}
}

void GridMesh::SetIntensity(double intensity)
{
	m_setIntensity = intensity;
    m_intensity = m_setIntensity/(m_size*m_size);
}

void GridMesh::SetAmpFilter(double ampFilter)
{
	m_ampFilter = ampFilter;
    m_bNeedRecreate = true;
}

void GridMesh::SetFreqFilter(double freqFilter)
{
    m_freqFilter = freqFilter;
    m_bNeedRecreate = true;
}

void GridMesh::SetTimeFilter(double timeFilter)
{
    m_timeFilter = timeFilter;
    m_bNeedRecreate = true;
}

void GridMesh::SetNumAnimationFrames(int numFrames)
{
    m_frames = numFrames;
    m_bNeedRecreate = true;
}

double GridMesh::Height(int x, int y)
{
    if (x < 0) x+= m_meshSize;
    if (y < 0) y+= m_meshSize;
    return *Height(m_frame, x % m_meshSize, y % m_meshSize);
}

double* GridMesh::Height(int frame, int x, int y)
{
	return m_mesh + frame*m_meshSize*m_meshSize + y*m_meshSize + x;
}

NormalNode* GridMesh::Normal(int x, int y)
{
    if (x < 0) x+= m_meshSize;
    if (y < 0) y+= m_meshSize;
    return (m_normals + m_meshSize*(y % m_meshSize) + (x % m_meshSize));
}

void GridMesh::SetCurrentFrameNr(int frameNr)
{
	m_frame = frameNr-1;
	if (m_bNeedRecreate) {
		Recreate();
	}
	CalculateNormals();
}

void GridMesh::Filter()
{
    int i, j, k;
    fftw_complex *tmp = new fftw_complex[m_frames*m_meshSize*(m_meshSize/2+1)];
    fftw_real scale = 1.0/(m_frames*m_meshSize*m_meshSize);
    rfftwnd_plan pf = rfftw3d_create_plan(m_frames, m_meshSize, m_meshSize, FFTW_REAL_TO_COMPLEX, FFTW_ESTIMATE);
    rfftwnd_plan pb = rfftw3d_create_plan(m_frames, m_meshSize, m_meshSize, FFTW_COMPLEX_TO_REAL, FFTW_ESTIMATE);
    
    // Transform to complex
    rfftwnd_one_real_to_complex(pf, m_mesh, tmp);

    // Filter spectrum
    for (k = 0; k < m_frames; k++) {
        double z;
        if (k <= m_frames/2) z = (double)k/m_frames;
        else z = (double)(m_frames-k)/m_frames;
        for (i = 0; i < m_meshSize; i++) {
            double x;
            if (i <= m_meshSize/2) x = (double)i/m_meshSize;
            else x = (double)(m_meshSize-i)/m_meshSize;
            for (j = 0; j < (m_meshSize/2+1); j++) {
                double y = (double)j/(m_meshSize);
                
                double r = sqrt(x*x+y*y);
                double f = m_ampFilter;
                f = f*m_meshSize/m_timeFilter*max((1-r*m_freqFilter*m_meshSize/m_timeFilter),0); // x-y axis
                f = f*max(1-z*4*m_frames/m_timeFilter,0)*m_frames/m_timeFilter; // Time axis
                (tmp + k*m_meshSize*(m_meshSize/2+1) + i*(m_meshSize/2+1) + j)->im *= f;
                (tmp + k*m_meshSize*(m_meshSize/2+1) + i*(m_meshSize/2+1) + j)->re *= f;
            }
        }
    }


    // Transform back to real
    rfftwnd_one_complex_to_real(pb, tmp, m_mesh);


    // Scale final result
    double amin = 10000, amax = -10000;
    for (k = 0; k < m_frames; k++) {
        for (i = 0; i < m_meshSize; i++) {
            for (j = 0; j < m_meshSize; j++) {
                *Height(k,j,i) *= scale;
                if (*Height(k,j,i) > amax) amax = *Height(k,j,i);
                if (*Height(k,j,i) < amin) amin = *Height(k,j,i);

            }
        }
    }
    printf("amin = %f amax = %f\n", amin, amax);
    rfftwnd_destroy_plan(pf);
    rfftwnd_destroy_plan(pb);

	delete [] tmp;
}

void GridMesh::CalculateNormals()
{
	if (m_normals == NULL) {
		return;
	}

    int x, y;
    // Reset normals
    for (y = 0; y < m_meshSize; y++) {
        for (x = 0; x < m_meshSize; x++) {
            NormalNode *n = Normal(x,y);
            n->cnt = 0;
            n->normal = Vector3D(0,0,0);
        }
    }
    for (y = 0; y < m_meshSize; y++) {
        for (x = 0; x < m_meshSize; x++) {
            Vector3D v00, v10, v11, v01, normal;
            v00 = Vector3D(((float)x)/m_size,((float)y)/m_size,     Height(x,y));
            v10 = Vector3D(((float)(x+1))/m_size,((float)y)/m_size, Height(x+1,y));
            v01 = Vector3D(((float)x)/m_size,((float)(y+1))/m_size, Height(x,y+1));
            v11 = Vector3D(((float)x+1)/m_size,((float)y+1)/m_size, Height(x+1,y+1));
            normal = Vector3D::CrossProduct(v10-v00, v11-v00);
            
            Normal(x,y)->cnt++;
            Normal(x,y)->normal += normal;
            Normal(x+1,y)->cnt++;
            Normal(x+1,y)->normal += normal;
            Normal(x+1,y+1)->cnt++;
            Normal(x+1,y+1)->normal += normal;
            
            normal = Vector3D::CrossProduct(v11-v00, v01-v00);
            Normal(x,y)->cnt++;
            Normal(x,y)->normal += normal;
            Normal(x+1,y+1)->cnt++;
            Normal(x+1,y+1)->normal += normal;
            Normal(x,y+1)->cnt++;
            Normal(x,y+1)->normal += normal;
        }
    }
    
    // normalize all
    for (y = 0; y < m_meshSize; y++) {
        for (x = 0; x < m_meshSize; x++) {
            if (Normal(x,y)->cnt != 0) {
                Normal(x,y)->normal = (Normal(x,y)->normal / Normal(x,y)->cnt).Normalized();
            }
        }
    }
}

// Draw final mesh
void GridMesh::Draw()
{
    if (m_bNeedRecreate) {
		// The mesh parameters has changed. Recreate the mesh.
    	Recreate();
    }

    
    double s = m_meshSize/m_size/2;
    printf("Frame: %d\n", m_frame);

#if 0 // Draw only one projected grid
    glDisable(GL_LIGHTING);
    DrawBlend(0,0);
    glEnable(GL_LIGHTING);
#endif

#if 1 // Draw 3x3 projected grids to create a true tileable grid in the middle
    s = m_meshSize/m_size;
    glDisable(GL_LIGHTING);
    DrawBlend(-s,-s);
    DrawBlend(0,-s);
    DrawBlend(s,-s);

    DrawBlend(-s,0);
    DrawBlend(0,0);
    DrawBlend(s,0);

    DrawBlend(-s,s);
    DrawBlend(0,s);
    DrawBlend(s,s);
    glEnable(GL_LIGHTING);
#endif

#if 0 // Draw the original mesh
    //glEnable(GL_BLEND);
    DrawMesh(0,0);
    //glDisable(GL_BLEND);
#endif
}

// Draw the original mesh
void GridMesh::DrawMesh(double x_off, double y_off)
{
    glPushMatrix();
	glTranslated(-m_meshSize/2/m_size+x_off, -m_meshSize/2/m_size+y_off, 0.0f);
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    for (int y = 0; y < m_meshSize; y++) {
        for (int x = 0; x < m_meshSize; x++) {
            /* Lower triangle (x,y),(x+1,y),(x+1,y+1) */
            Vector3D n = Normal(x,y)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d(x/m_size, y/m_size, Height(x,y));
            
            n = Normal(x+1,y)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d((x+1)/m_size, y/m_size, Height(x+1,y));

            n = Normal(x+1,y+1)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d((x+1)/m_size, (y+1)/m_size, Height(x+1,y+1));
            /* Upper triangle (x,y),(x+1,y+1),(x,y+1) */
            n = Normal(x,y)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d(x/m_size, y/m_size, Height(x,y));

            n = Normal(x+1,y+1)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d((x+1)/m_size, (y+1)/m_size, Height(x+1,y+1));

            n = Normal(x,y+1)->normal;
            glNormal3d(n.x, n.y, n.z);
            glVertex3d(x/m_size, (y+1)/m_size, Height(x,y+1));
        }
    }
    glEnd();

#if 0 // draw normals
    glBegin(GL_LINES);
    for (y = 0; y <= m_meshSize; y++) {
        for (int x = 0; x <= m_meshSize; x++) {
            Vector3D n = Normal(x,y)->normal;
            Vector3D a = Vector3D(x/m_size, y/m_size, Height(x,y));
            Vector3D b = a+n*0.1;

            glVertex3d(a.x,a.y,a.z);
            glVertex3d(b.x,b.y,b.z);
        }
    }
    glEnd();
#endif
    glPopMatrix();
}

// Draw a projected mesh
void GridMesh::DrawBlend(double x_off, double y_off)
{
    int x, y;
    float intensity;
    glPushMatrix();
	glTranslated(-m_meshSize/2/m_size+x_off, -m_meshSize/2/m_size+y_off, -1.5f);

    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE,GL_ONE);
    glDisable(GL_DEPTH_TEST);


    for (y = 0; y < m_meshSize; y++) {
        for (x = 0; x < m_meshSize; x++) {
            Vector3D v00, v10, v11, v01, normal;
            v00 = Vector3D(((float)x)/m_size,((float)y)/m_size,     Height(x,y));
            v10 = Vector3D(((float)(x+1))/m_size,((float)y)/m_size, Height(x+1,y));
            v01 = Vector3D(((float)x)/m_size,((float)(y+1))/m_size, Height(x,y+1));
            v11 = Vector3D(((float)x+1)/m_size,((float)y+1)/m_size, Height(x+1,y+1));
            normal = Vector3D::CrossProduct(v10-v00, v11-v00);

            /* Refract lower triangle */
            Vector3D rv1 = ProjectRay(v00, RefractionVector(Vector3D(0, 0, -1), Normal(x,y)->normal, 1.0f, 1.33f));
            Vector3D rv2 = ProjectRay(v10, RefractionVector(Vector3D(0, 0, -1), Normal(x+1,y)->normal, 1.0f, 1.33f));
            Vector3D rv3 = ProjectRay(v11, RefractionVector(Vector3D(0, 0, -1), Normal(x+1,y+1)->normal, 1.0f, 1.33f));

            // Heron of Alexandria area calculation
            float l1 = (float)(rv2-rv1).Length();
            float l2 = (float)(rv3-rv1).Length();
            float l3 = (float)(rv3-rv2).Length();
            float s = (l1 + l2 + l3)/2;
            float area = (float)sqrt(s*(s-l1)*(s-l2)*(s-l3));
            intensity = (float)(m_intensity / area);

            if (rv1.z < 0 && rv2.z < 0 && rv3.z < 0) {
                rv1.z = 0; // draw it at distance 0
                rv2.z = 0;
                rv3.z = 0;
                glBegin(GL_TRIANGLES);								// Start Drawing A Triangle
		            glColor3f(intensity,intensity,intensity);						// Set Top Point Of Triangle To Red
		            glVertex3f((float)rv1.x, (float)rv1.y, (float)rv1.z);
		            glColor3f(intensity,intensity,intensity);						// Set Left Point Of Triangle To Green
		            glVertex3f((float)rv2.x, (float)rv2.y, (float)rv2.z);
		            glColor3f(intensity,intensity,intensity);						// Set Right Point Of Triangle To Blue
		            glVertex3f((float)rv3.x, (float)rv3.y, (float)rv3.z);
	            glEnd();											// Done Drawing The Triangle
            }

            normal = Vector3D::CrossProduct(v11-v00, v10-v00);
            rv1 = ProjectRay(v00, RefractionVector(Vector3D(0, 0, -1), Normal(x,y)->normal, 1.0f, 1.33f));
            rv2 = ProjectRay(v11, RefractionVector(Vector3D(0, 0, -1), Normal(x+1,y+1)->normal, 1.0f, 1.33f));
            rv3 = ProjectRay(v01, RefractionVector(Vector3D(0, 0, -1), Normal(x,y+1)->normal, 1.0f, 1.33f));

            l1 = (float)(rv2-rv1).Length();
            l2 = (float)(rv3-rv1).Length();
            l3 = (float)(rv3-rv2).Length();
            s = (l1 + l2 + l3)/2;
            area = (float)sqrt(s*(s-l1)*(s-l2)*(s-l3));
            intensity = (float)(m_intensity / area);

            if (rv1.z < 0 && rv2.z < 0 && rv3.z < 0) {
                rv1.z = 0;
                rv2.z = 0;
                rv3.z = 0;
                glBegin(GL_TRIANGLES);								// Start Drawing A Triangle
		            glColor3f(intensity,intensity,intensity);						// Set Top Point Of Triangle To Red
		            glVertex3f((float)rv1.x, (float)rv1.y, (float)rv1.z);
		            glColor3f(intensity,intensity,intensity);						// Set Left Point Of Triangle To Green
		            glVertex3f((float)rv2.x, (float)rv2.y, (float)rv2.z);
		            glColor3f(intensity,intensity,intensity);						// Set Right Point Of Triangle To Blue
		            glVertex3f((float)rv3.x, (float)rv3.y, (float)rv3.z);
	            glEnd();											// Done Drawing The Triangle
            }
        }
    }
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    glPopMatrix();
}

// Refract a ray from one medium to another
Vector3D GridMesh::RefractionVector(Vector3D &v1, Vector3D &normal, double i1, double i2)
{
    Vector3D rv(0, 0, 0);

    double NL = Vector3D::DotProduct(normal, v1);

    rv = normal*((i1/i2)*NL - sqrt(1 - (i1/i2)*(i1/i2)*NL*NL)) - v1*(i1/i2);

    return rv;
}

// Project the ray at some depth
Vector3D GridMesh::ProjectRay(Vector3D &v1, Vector3D &dir)
{
    double h = m_depth - v1.z;
    Vector3D H = Vector3D(0, 0, -h);
    Vector3D Pv = v1 + ((dir * h) / (dir.Length() * Vector3D::DotProduct(dir.Normalized(), H.Normalized())));
    return Pv;
}

void GridMesh::SaveToFile(FILE *outFile)
{
	fprintf(outFile, "<CAUSTICS>\n");
	fprintf(outFile, "\t<DEPTH value=\"%f\"/>\n", GetDepth());
	fprintf(outFile, "\t<INTENSITY value=\"%f\"/>\n", GetIntensity());
	fprintf(outFile, "\t<AMP_FILTER value=\"%f\"/>\n", GetAmpFilter());
	fprintf(outFile, "\t<FREQ_FILTER value=\"%f\"/>\n", GetFreqFilter());
	fprintf(outFile, "\t<TIME_FILTER value=\"%f\"/>\n", GetTimeFilter());
	fprintf(outFile, "\t<NUM_ANIM_FRAMES value=\"%d\"/>\n", GetNumAnimationFrames());
	fprintf(outFile, "\t<CURRENT_ANIM_FRAME value=\"%d\"/>\n", GetCurrentFrameNr());
	fprintf(outFile, "\t<SUBDIVISIONS value=\"%d\"/>\n", GetResultion());
	fprintf(outFile, "</CAUSTICS>\n");
}

void GridMesh::ParseConfig(pug::xml_node *rootNode)
{
	for (int i=0; i < rootNode->children(); i++) {
		pug::xml_node itemNode = rootNode->child(i);

		float fValue = 0;
		int iValue = 0;

		if (stricmp("DEPTH", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%f", &fValue);
			SetDepth(fValue);
		}
		if (stricmp("INTENSITY", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%f", &fValue);
			SetIntensity(fValue);
		}
		if (stricmp("AMP_FILTER", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%f", &fValue);
			SetAmpFilter(fValue);
		}
		if (stricmp("FREQ_FILTER", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%f", &fValue);
			SetFreqFilter(fValue);
		}
		if (stricmp("TIME_FILTER", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%f", &fValue);
			SetTimeFilter(fValue);
		}
		if (stricmp("NUM_ANIM_FRAMES", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%i", &iValue);
			SetNumAnimationFrames(iValue);
		}
		if (stricmp("CURRENT_ANIM_FRAME", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%i", &iValue);
			SetCurrentFrameNr(iValue);
		}
		if (stricmp("SUBDIVISIONS", itemNode.name()) == 0) {
			sscanf(itemNode.attribute("value").value(), "%i", &iValue);
			SetResolution(iValue);
		}
	}
}


