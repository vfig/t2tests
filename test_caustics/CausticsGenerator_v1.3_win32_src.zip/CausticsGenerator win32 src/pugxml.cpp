#include "pugxml.h"

namespace pug
{

int strcmpwild_impl(const TCHAR* src,const TCHAR* dst);
inline int pug::strcmpwild_cset(const TCHAR** src,const TCHAR** dst);

//<summary>Wildcard pattern match.</summary>
//<param name="lhs">String or expression for left-hand side of comparison.</param>
//<param name="rhs">String for right-hand side of comparison.</param>
//<remarks>Used by 'strcmpwild'.</remarks>
int strcmpwild_astr(const TCHAR** src,const TCHAR** dst)
{
	int find = 1;
	++(*src);
	while((**dst != 0 && **src == _T('?')) || **src == _T('*'))
	{
		if(**src == _T('?')) ++(*dst);
		++(*src);
	}
	while(**src == _T('*')) ++(*src);
	if(**dst == 0 && **src != 0) return 0;
	if(**dst == 0 && **src == 0) return 1;
	else
	{
		if(strcmpwild_impl(*src,*dst) == 0)
		{
			do
			{
				++(*dst);
				while(**src != **dst && **src != _T('[') && **dst != 0) 
					++(*dst);
			}
			while((**dst != 0) ? strcmpwild_impl(*src,*dst) == 0 : 0 != (find=0));
		}
		if(**dst == 0 && **src == 0) find = 1;
		return find;
	}
}

//<summary>Compare two strings, with globbing, and character sets.</summary>
//<param name="lhs">String or expression for left-hand side of comparison.</param>
//<param name="rhs">String for right-hand side of comparison.</param>
//<remarks>Used by 'strcmpwild'.</remarks>
int strcmpwild_impl(const TCHAR* src,const TCHAR* dst)
{
	int find = 1;
	for(; *src != 0 && find == 1 && *dst != 0; ++src)
	{
		switch(*src)
		{
		case _T('?'): ++dst; break;
		case _T('['): ++src; find = strcmpwild_cset(&src,&dst); break;
		case _T('*'): find = strcmpwild_astr(&src,&dst); --src; break;
		default : find = (int) (*src == *dst); ++dst;
		}
	}
	while(*src == _T('*') && find == 1) ++src;
	return (int) (find == 1 && *dst == 0 && *src == 0);
}

//<summary>Character set pattern match.</summary>
//<param name="lhs">String or expression for left-hand side of comparison.</param>
//<param name="rhs">String for right-hand side of comparison.</param>
//<remarks>Used by 'strcmpwild'.</remarks>
inline int strcmpwild_cset(const TCHAR** src,const TCHAR** dst)
{
	int find = 0;
	int excl = 0;
	int star = 1;
	if(**src == _T('!'))
	{
		excl = 1;
		++(*src);
	}
	while(**src != _T(']') || star == 1)
	{
		if(find == 0)
		{
			if(**src == _T('-') && *(*src-1) < *(*src+1) && *(*src+1) != _T(']') && star == 0)
			{
				if(**dst >= *(*src-1) && **dst <= *(*src+1))
				{
					find = 1;
					++(*src);
				}
			}
			else if(**src == **dst) find = 1;
		}
		++(*src);
		star = 0;
	}
	if(excl == 1) find = (1 - find);
	if(find == 1) ++(*dst);
	return find;
}

}