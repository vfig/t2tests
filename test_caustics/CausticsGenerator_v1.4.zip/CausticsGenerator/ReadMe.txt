Caustics Generator v1.4

http://www.lysator.liu.se/~kand/caustics/

Copyright (c) 2003-2005
Kjell Andersson (kand@lysator.liu.se)
Mathias Bergvall

ABOUT
-----

Caustics can be described as the light pattern you see at the bottom of a pool
on a sunny day. This tool will let you render such caustics patterns. The
rendered images can be animated and used for realtime graphics and are
tileable in both space and time. 

LICENSE
-------
This program is released as free software under GNU GPL.
See http://www.gnu.org/licenses/gpl.html

If you use this program to create images for any commercial product, please
give us some credit.

HISTORY
-------

v1.4 2005-01-19
 - Motion blur filtering support.
 - Added progress dialog when rending single frames and animations.
 - Added minimize button on main window.

v1.31 2004-09-29
 - Maximum resolution increased from 1024x1024 to 8096x8096

v1.3 2003-08-06
 - Load/Save functionality.
 - Background color can now be set by the user.
 - File dialog for selecting output filename.

v1.2 2003-05-16
 - Time filter control added.
   This will allow you to control how vivid the animation shall be.

v1.1 2003-03-21
 - Fixed crash in render animation feature,

v1.0 2003-03-18
 - First release
